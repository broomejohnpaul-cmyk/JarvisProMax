package com.jarvis.promax.ai

import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class GPTManager {

    private val client = OkHttpClient()
    private val API_KEY = "YOUR_API_KEY_HERE"

    fun askJarvis(prompt: String, callback: (String) -> Unit) {

        val json = JSONObject()
        json.put("model", "gpt-4o-mini")
        json.put("input", prompt)

        val body = RequestBody.create(
            MediaType.parse("application/json"),
            json.toString()
        )

        val request = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer $API_KEY")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                callback(response.body()?.string() ?: "")
            }
        })
    }
}