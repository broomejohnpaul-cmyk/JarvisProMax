package com.jarvis.promax

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.promax.ai.GPTManager

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val button = Button(this)
        button.text = "Start Jarvis"
        setContentView(button)

        val gpt = GPTManager()

        button.setOnClickListener {
            gpt.askJarvis("Hello Jarvis") {
                println(it)
            }
        }
    }
}